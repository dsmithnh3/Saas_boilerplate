export { GET, POST } from '@/server/auth';
